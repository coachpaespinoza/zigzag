# Cómo probar ZIGZAG en tu Android

Este paquete contiene el código fuente, NO un APK.

1. Abre tu repositorio GitHub `coachpaespinoza/zigzag`.
2. Sube el CONTENIDO de la carpeta `zigzag-app` de este ZIP a la raíz del repositorio, conservando `.github/workflows/android-apk.yml`. Puedes hacerlo desde GitHub web con Upload files o con GitHub Desktop.
3. Abre la pestaña Actions, el flujo **Generar APK ZIGZAG** y espera a que termine. Si no se activa, elige Run workflow.
4. En la ejecución exitosa, baja el artefacto **ZIGZAG-Android-APK-pruebas**, descomprímelo e instala `app-debug.apk` en tu teléfono Android.
5. Si la ejecución falla, comparte el registro del paso que falló. No hay que volver a subir el proyecto completo para diagnosticarlo.

Importante: no se ha podido verificar `npm run build` en este entorno porque el acceso a registry.npmjs.org falla. La prueba de GitHub Actions permitirá comprobarlo.
